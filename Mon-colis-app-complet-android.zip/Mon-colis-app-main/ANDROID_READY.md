# MON Colis — structure Android

Le projet contient maintenant le dossier `android/` et une structure Android Flutter compatible avec le projet.

Pour une compilation locale avec Flutter, exécuter :

```bash
flutter pub get
flutter build apk --release
```

Le workflow GitHub Actions peut également compléter/actualiser les fichiers Android avec `flutter create --platforms=android --project-name moncolis .` avant la compilation.
