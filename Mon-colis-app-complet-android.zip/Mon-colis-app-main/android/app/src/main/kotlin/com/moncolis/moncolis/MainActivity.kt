package com.moncolis.moncolis

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
